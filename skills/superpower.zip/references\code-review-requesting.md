# Requesting Code Review

Review early, review often to catch issues before they cascade.

## When to Request

**Mandatory:**
- After each task in subagent-driven development
- After completing major feature
- Before merge to main

**Optional but valuable:**
- When stuck (fresh perspective)
- Before refactoring (baseline check)
- After fixing complex bug

## How to Request

1. **Get git SHAs:**
```bash
BASE_SHA=$(git rev-parse HEAD~1)
HEAD_SHA=$(git rev-parse HEAD)
```

2. **Dispatch code-reviewer subagent** with:
- WHAT_WAS_IMPLEMENTED
- PLAN_OR_REQUIREMENTS
- BASE_SHA
- HEAD_SHA
- DESCRIPTION

3. **Act on feedback:**
- Fix Critical issues immediately
- Fix Important issues before proceeding
- Note Minor issues for later
- Push back if reviewer is wrong

## Integration with Workflows

**Subagent-Driven Development:**
- Review after EACH task
- Catch issues before they compound

**Executing Plans:**
- Review after each batch (3 tasks)

**Ad-Hoc Development:**
- Review before merge
- Review when stuck