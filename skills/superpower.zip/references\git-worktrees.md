# Using Git Worktrees

Create isolated workspaces for parallel development.

## Overview

Git worktrees create isolated workspaces sharing the same repository, allowing work on multiple branches simultaneously without switching.

## Directory Selection

### Priority Order:

1. **Check Existing Directories:**
```bash
ls -d .worktrees 2>/dev/null    # Preferred
ls -d worktrees 2>/dev/null     # Alternative
```

2. **Check CLAUDE.md:**
```bash
grep -i "worktree.*director" CLAUDE.md
```

3. **Ask User** if no preference specified

## Safety Verification

**For Project-Local Directories:**

MUST verify directory is ignored:
```bash
git check-ignore -q .worktrees 2>/dev/null || git check-ignore -q worktrees 2>/dev/null
```

**If NOT ignored:**
1. Add to .gitignore
2. Commit the change
3. Proceed with worktree creation

## Creation Steps

1. **Detect Project Name:**
```bash
project=$(basename "$(git rev-parse --show-toplevel)")
```

2. **Create Worktree:**
```bash
git worktree add "$path" -b "$BRANCH_NAME"
cd "$path"
```

3. **Set up development environment**

## When to Use

- Starting feature work needing isolation
- Before executing implementation plans
- Parallel development on multiple features