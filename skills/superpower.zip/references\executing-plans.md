# Executing Plans

Execute tasks from written plan in separate session with checkpoints.

## Overview

Load plan, review critically, execute all tasks, report when complete.

**Announce:** "I'm using the executing-plans skill to implement this plan."

## The Process

### Step 1: Load and Review Plan
1. Read plan file
2. Review critically
3. Raise concerns before starting
4. Create TodoWrite and proceed

### Step 2: Execute Tasks

For each task:
1. Mark as in_progress
2. Follow each step exactly
3. Run verifications as specified
4. Mark as completed

### Step 3: Complete Development

- Use finishing-a-development-branch
- Verify tests
- Present options
- Execute choice

## When to Stop

**STOP immediately when:**
- Hit a blocker
- Plan has critical gaps
- Verification fails repeatedly

**Ask for clarification** rather than guessing.

## Integration

**Required workflow skills:**
- superpower:using-git-worktrees - Set up workspace
- superpower:writing-plans - Creates the plan
- superpower:finishing-a-development-branch - Complete development

## Note

Superpowers works much better with subagent support. If available, use superpower:subagent-driven-development instead.