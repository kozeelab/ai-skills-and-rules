# Test-Driven Development (TDD)

Write the test first. Watch it fail. Write minimal code to pass.

## The Iron Law

```
NO PRODUCTION CODE WITHOUT A FAILING TEST FIRST
```

## Red-Green-Refactor Cycle

```dot
digraph tdd_cycle {
    RED [label="RED\nWrite failing test" style=filled fillcolor="#ffcccc"];
    VERIFY_RED [label="Verify fails\ncorrectly"];
    GREEN [label="GREEN\nMinimal code" style=filled fillcolor="#ccffcc"];
    VERIFY_GREEN [label="Verify passes"];
    REFACTOR [label="REFACTOR\nClean up" style=filled fillcolor="#ccccff"];

    RED -> VERIFY_RED;
    VERIFY_RED -> GREEN [label="yes"];
    VERIFY_RED -> RED [label="wrong failure"];
    GREEN -> VERIFY_GREEN;
    VERIFY_GREEN -> REFACTOR [label="yes"];
    VERIFY_GREEN -> GREEN [label="no"];
    REFACTOR -> VERIFY_GREEN;
}
```

### RED - Write Failing Test

Write one minimal test showing what should happen:

```typescript
test('retries failed operations 3 times', async () => {
  let attempts = 0;
  const operation = () => {
    attempts++;
    if (attempts < 3) throw new Error('fail');
    return 'success';
  };

  const result = await retryOperation(operation);
  expect(result).toBe('success');
  expect(attempts).toBe(3);
});
```

### Verify RED - Watch It Fail

**MANDATORY.** Run the test and confirm:
- Test fails (not errors)
- Failure message is expected
- Fails because feature missing

### GREEN - Minimal Code

Write simplest code to pass the test. Don't add features, refactor other code, or "improve" beyond the test.

### Verify GREEN - Watch It Pass

**MANDATORY.** Run tests and confirm:
- Test passes
- Other tests still pass
- Output pristine

### REFACTOR - Clean Up

After green only:
- Remove duplication
- Improve names
- Extract helpers

## When to Use

**Always:**
- New features
- Bug fixes
- Refactoring
- Behavior changes

**Exceptions (ask your human):**
- Throwaway prototypes
- Generated code
- Configuration files

## Good Tests

| Quality | Good | Bad |
|---------|------|-----|
| Name | Clear behavior | Vague |
| Content | Tests real code | Tests mocks |
| Scope | One behavior | Many behaviors |

## Anti-Patterns

- **Long tests** - Split into smaller tests
- **Mock overuse** - Test real behavior when possible
- **Implementation details** - Test observable behavior
- **Assertions without logic** - Each assertion should fail for a reason