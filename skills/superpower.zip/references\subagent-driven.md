# Subagent-Driven Development

Execute plan by dispatching fresh subagent per task with two-stage review.

## Core Principle

```
Fresh subagent per task + two-stage review (spec then quality) = high quality, fast iteration
```

## When to Use

- Have implementation plan
- Tasks mostly independent
- Stay in this session

**vs. Executing Plans (parallel session):**
- Same session (no context switch)
- Fresh subagent per task (no context pollution)
- Two-stage review after each task
- Faster iteration

## The Process

```
Per Task:
1. Dispatch implementer subagent
2. Implementer implements, tests, commits
3. Dispatch spec compliance reviewer
4. If issues: implementer fixes
5. Dispatch code quality reviewer
6. If issues: implementer fixes
7. Mark task complete

After all tasks:
- Final code review
- Use finishing-a-development-branch
```

## Model Selection

| Task Type | Model |
|-----------|-------|
| Mechanical (1-2 files, clear spec) | Fast, cheap |
| Integration (multi-file) | Standard |
| Architecture, design, review | Most capable |

## Handling Implementer Status

| Status | Action |
|--------|--------|
| DONE | Proceed to spec review |
| DONE_WITH_CONCERNS | Read concerns, address if correctness issue |
| NEEDS_CONTEXT | Provide missing context, re-dispatch |
| BLOCKED | Assess blocker, adjust approach |

## Two-Stage Review

### Stage 1: Spec Compliance
- Does code match spec?
- All requirements met?
- Nothing extra added?

### Stage 2: Code Quality
- Good test coverage?
- Clean code?
- Any issues?

## Example

```
Task 1: Hook installation
[Dispatch implementer]
[Spec reviewer: ✅ compliant]
[Code reviewer: Approved]

Task 2: Recovery modes
[Dispatch implementer]
[Spec reviewer: ❌ missing progress reporting]
[Implementer fixes]
[Spec reviewer: ✅]
[Code reviewer: Approved]

[All tasks complete]
[Final review]
[finishing-a-development-branch]
```