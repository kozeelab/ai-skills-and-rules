---
name: superpower
description: "You MUST use this when starting ANY conversation, BEFORE any implementation, planning, or code writing. Superpowers is a complete software development methodology - it covers brainstorming design, writing plans, TDD, debugging, code review, subagent workflows, and finishing development. Use this skill whenever the user wants to build features, fix bugs, plan work, review code, or do any software development task. This skill activates automatically at the start of any development conversation - there is no excuse for skipping the design phase. If there's any chance you're about to write code, you MUST check this skill first."
---

# Superpowers - Complete Software Development Methodology

Superpowers is a comprehensive development methodology that activates at the start of any coding task. It ensures systematic, high-quality software development through composable skills that trigger automatically.

## Core Workflow

```dot
digraph superpower_workflow {
    rankdir=TB;
    START [shape=doublecircle label="User wants to build/fix something"];
    BRAINSTORM [shape=box label="superpower:brainstorming\nExplore & design first"];
    PLAN [shape=box label="superpower:writing-plans\nCreate implementation plan"];
    IMPLEMENT [shape=diamond label="How to implement?"];
    SUBAGENT [shape=box label="subagent-driven-development\n(recommended - same session)"];
    EXECUTING [shape=box label="executing-plans\n(separate session)"];
    REVIEW [shape=box label="requesting-code-review\nReview each task"];
    FINISH [shape=box label="finishing-a-development-branch\nMerge/PR/cleanup"];
    DEBUG [shape=box label="systematic-debugging\nFix bugs properly"];
    TDD [shape=box label="test-driven-development\nRED-GREEN-REFACTOR"];

    START -> BRAINSTORM;
    BRAINSTORM -> PLAN;
    PLAN -> IMPLEMENT;
    IMPLEMENT -> SUBAGENT [label="same session"];
    IMPLEMENT -> EXECUTING [label="separate session"];
    SUBAGENT -> REVIEW;
    EXECUTING -> REVIEW;
    REVIEW -> TDD;
    TDD -> FINISH;
    FINISH -> DEBUG [label="if bugs found"];
}
```

## The Iron Rules

### Rule 1: Brainstorming BEFORE Code

```
NO IMPLEMENTATION WITHOUT DESIGN APPROVAL
```

If you think there's even a 1% chance you're about to write code, you MUST invoke the brainstorming skill first. "Simple" projects cause the most wasted work when skipped.

### Rule 2: Evidence BEFORE Claims

```
NO COMPLETION CLAIMS WITHOUT VERIFICATION
```

Never claim "tests pass" without running them. Never claim "bug fixed" without testing. Evidence over assertions, always.

### Rule 3: Root Cause BEFORE Fixes

```
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION
```

When bugs occur, find the root cause before attempting solutions. Symptom fixing creates new bugs.

## When to Use Each Sub-Skill

| Situation | Use This Sub-Skill |
|-----------|-------------------|
| Starting any new feature/bugfix | [brainstorming](#brainstorming) - design first |
| Have spec, need implementation plan | [writing-plans](#writing-plans) |
| Execute plan in current session | [subagent-driven-development](#subagent-driven-development) |
| Execute plan in separate session | [executing-plans](#executing-plans) |
| Writing any code | [test-driven-development](#test-driven-development) |
| Found a bug | [systematic-debugging](#systematic-debugging) |
| About to claim work is done | [verification-before-completion](#verification-before-completion) |
| Completed a task, need review | [requesting-code-review](#requesting-code-review) |
| Received review feedback | [receiving-code-review](#receiving-code-review) |
| Starting feature work | [using-git-worktrees](#using-git-worktrees) |
| Implementation complete | [finishing-a-development-branch](#finishing-a-development-branch) |
| Creating new skills | [writing-skills](#writing-skills) |
| Learning about Superpowers | [using-superpowers](#using-superpowers) |
| Multiple independent problems | [dispatching-parallel-agents](#dispatching-parallel-agents) |

## Sub-Skill Quick Reference

### brainstorming
Start here. Refine ideas through questions, explore alternatives, present design in sections for validation. Creates design document in `docs/superpowers/specs/`.

**Triggers:** Before any creative work - features, components, functionality, behavior changes.

### writing-plans
Transform approved design into detailed implementation plan. Bite-sized tasks (2-5 min each) with exact file paths and complete code. Saves to `docs/superpowers/plans/`.

**Triggers:** After design approval, before implementation.

### test-driven-development
RED-GREEN-REFACTOR cycle. Write failing test, watch it fail, write minimal code, watch it pass, commit.

**Triggers:** During any implementation - new features, bug fixes, refactoring.

### systematic-debugging
4-phase root cause process. Find root cause BEFORE proposing fixes. Evidence over assumptions.

**Triggers:** Any bug, test failure, unexpected behavior.

### verification-before-completion
Run verification commands and confirm output before making any success claims.

**Triggers:** Before claiming work is complete, before commits/PRs.

### requesting-code-review
Dispatch code review to catch issues before they cascade. Review early, review often.

**Triggers:** After each task, after major features, before merge.

### receiving-code-review
Respond to feedback with technical rigor. Verify before implementing. Push back when wrong.

**Triggers:** When receiving code review feedback.

### using-git-worktrees
Create isolated workspaces for parallel development. Smart directory selection with safety verification.

**Triggers:** Before starting feature work, before executing plans.

### finishing-a-development-branch
Verify tests, present merge/PR options, execute choice, cleanup.

**Triggers:** When implementation complete and all tests pass.

### subagent-driven-development
Dispatch fresh subagent per task with two-stage review (spec compliance, then code quality). Fast iteration in current session.

**Triggers:** When executing implementation plan with independent tasks.

### executing-plans
Execute tasks from written plan in separate session with checkpoints.

**Triggers:** When plan exists but subagent support unavailable.

### dispatching-parallel-agents
Dispatch one agent per independent problem domain for concurrent investigation.

**Triggers:** Multiple independent failures that can be investigated in parallel.

### writing-skills
Create new skills following Superpowers best practices with testing methodology.

**Triggers:** When creating new skills for the system.

### using-superpowers
Introduction to the skills system, how to access and invoke skills.

**Triggers:** For understanding the Superpowers system itself.

## Platform Adaptation

Skills use Claude Code tool names. For other platforms, see `references/`:
- `copilot-tools.md` - Copilot CLI tool mappings
- `codex-tools.md` - Codex tool mappings
- `gemini-tools.md` - Gemini CLI tool mappings

## Complete Skill Loading

To load a specific sub-skill, use the Skill tool with the appropriate reference:

```markdown
# For detailed guidance on any sub-skill, read the reference:

- references/brainstorming.md
- references/writing-plans.md
- references/tdd.md
- references/debugging.md
- references/verification.md
- references/code-review-requesting.md
- references/code-review-receiving.md
- references/git-worktrees.md
- references/finishing.md
- references/subagent-driven.md
- references/executing-plans.md
- references/dispatching-parallel.md
- references/writing-skills.md
- references/using-superpowers.md
```

## Key Principles

1. **YAGNI ruthlessly** - Remove unnecessary features from all designs
2. **DRY** - Don't repeat yourself
3. **TDD** - Test first, always
4. **Process over guessing** - Systematic debugging beats random attempts
5. **Evidence over claims** - Verify before declaring success
6. **Design before implementation** - 5 minutes of design saves hours of rework

## Getting Started

When a user says "build X", "add Y", "fix Z", or any development task:

1. **Invoke this skill** - Load superpower methodology
2. **Follow brainstorming** - Understand what they're really building
3. **Create design doc** - Save to `docs/superpowers/specs/`
4. **Write implementation plan** - Save to `docs/superpowers/plans/`
5. **Execute with TDD** - Use subagent-driven-development
6. **Review each task** - Catch issues early
7. **Finish properly** - Verify, merge, cleanup

---

*Superpowers methodology from [obra/superpowers](https://github.com/obra/superpowers)*