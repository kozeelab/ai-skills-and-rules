# Systematic Debugging

Find root cause BEFORE attempting fixes.

## The Iron Law

```
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST
```

## The Four Phases

### Phase 1: Root Cause Investigation

1. **Read Error Messages Carefully**
   - Read stack traces completely
   - Note line numbers, file paths, error codes

2. **Reproduce Consistently**
   - Can you trigger it reliably?
   - What are the exact steps?

3. **Check Recent Changes**
   - What changed that could cause this?
   - Git diff, recent commits

4. **Gather Evidence in Multi-Component Systems**
   ```
   For EACH component boundary:
     - Log what data enters component
     - Log what data exits component
     - Verify environment/config propagation
   ```

5. **Trace Data Flow**
   - Where does bad value originate?
   - What called this with bad value?
   - Keep tracing up until you find the source

### Phase 2: Pattern Analysis

1. **Find Working Examples** - Similar working code in same codebase
2. **Compare Against References** - Read reference implementations completely
3. **Identify Differences** - What's different between working and broken?
4. **Understand Dependencies** - What does this need?

### Phase 3: Hypothesis and Testing

1. **Form Single Hypothesis** - "I think X is root cause because Y"
2. **Test Minimally** - Smallest possible change
3. **Verify Before Continuing**
4. **When You Don't Know** - Say so, don't pretend

### Phase 4: Implementation

1. **Create Failing Test Case** - Simplest reproduction
2. **Implement Single Fix** - One change at a time
3. **Verify Fix** - Test passes, no regressions
4. **If 3+ Fixes Failed** - Question architecture

## When to Use

- Test failures
- Bugs in production
- Unexpected behavior
- Performance problems
- Build failures

**Use ESPECIALLY when:**
- Under time pressure
- "Just one quick fix" seems obvious
- You've tried multiple fixes
- Previous fix didn't work