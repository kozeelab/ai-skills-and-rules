# Writing Plans

Transform approved design into detailed implementation plan.

## Overview

Write comprehensive implementation plans assuming the engineer has zero context. Document everything: which files to touch, code, testing, docs, how to verify.

## File Structure

Before defining tasks, map out which files will be created or modified:
- Design units with clear boundaries
- Each file has one clear responsibility
- Files that change together should live together
- Follow established patterns in existing codebases

## Task Granularity

**Each step is one action (2-5 minutes):**
- "Write the failing test"
- "Run it to make sure it fails"
- "Implement the minimal code to make the test pass"
- "Run the tests and make sure they pass"
- "Commit"

## Plan Document Header

```markdown
# [Feature Name] Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpower:subagent-driven-development (recommended) or superpower:executing-plans to implement this plan task-by-task.

**Goal:** [One sentence]

**Architecture:** [2-3 sentences]

**Tech Stack:** [Key technologies]
```

## Task Structure

```markdown
### Task N: [Component Name]

**Files:**
- Create: `exact/path/to/file.py`
- Modify: `exact/path/to/existing.py:123-145`
- Test: `tests/exact/path/to/test.py`

- [ ] **Step 1: Write the failing test**
- [ ] **Step 2: Run test to verify it fails**
- [ ] **Step 3: Write minimal implementation**
- [ ] **Step 4: Run test to verify it passes**
- [ ] **Step 5: Commit**
```

## No Placeholders

Never write:
- "TBD", "TODO", "implement later"
- "Add appropriate error handling"
- "Write tests for the above"
- "Similar to Task N"

## Self-Review

1. **Spec coverage:** Can you point to a task for each spec requirement?
2. **Placeholder scan:** Search for red flags
3. **Type consistency:** Do types match across tasks?

## Execution Handoff

**"Plan complete. Two execution options:**

**1. Subagent-Driven (recommended)** - superpower:subagent-driven-development
**2. Inline Execution** - superpower:executing-plans