# Brainstorming

Help turn ideas into fully formed designs and specs through natural collaborative dialogue.

## The Hard Gate

```
DO NOT invoke any implementation skill, write any code, scaffold any project, or take any implementation action until you have presented a design and the user has approved it.
```

## Checklist

1. **Explore project context** — check files, docs, recent commits
2. **Offer visual companion** (if visual questions ahead)
3. **Ask clarifying questions** — one at a time
4. **Propose 2-3 approaches** — with trade-offs and recommendation
5. **Present design** — in sections, get user approval after each
6. **Write design doc** — save to `docs/superpowers/specs/YYYY-MM-DD-<topic>-design.md`
7. **Spec self-review** — check for placeholders, contradictions, ambiguity
8. **User reviews written spec**
9. **Transition to implementation** — invoke writing-plans

## Process Flow

```dot
digraph brainstorming {
    "Explore project context" -> "Visual questions ahead?";
    "Visual questions ahead?" -> "Offer Visual Companion" [label="yes"];
    "Visual questions ahead?" -> "Ask clarifying questions" [label="no"];
    "Offer Visual Companion" -> "Ask clarifying questions";
    "Ask clarifying questions" -> "Propose 2-3 approaches";
    "Propose 2-3 approaches" -> "Present design sections";
    "Present design sections" -> "User approves design?";
    "User approves design?" -> "Write design doc" [label="yes"];
    "User approves design?" -> "Present design sections" [label="revise"];
    "Write design doc" -> "Spec self-review";
    "Spec self-review" -> "User reviews spec?";
    "User reviews spec?" -> "Invoke writing-plans" [label="approved"];
}
```

## Understanding the Idea

- Check project state first (files, docs, recent commits)
- If request describes multiple independent subsystems, decompose first
- Ask questions one at a time
- Prefer multiple choice questions
- Focus on: purpose, constraints, success criteria

## Presenting Design

- Scale each section to its complexity
- Ask after each section whether it looks right
- Cover: architecture, components, data flow, error handling, testing
- Be ready to go back and clarify

## After Design

- Write spec to `docs/superpowers/specs/YYYY-MM-DD-<topic>-design.md`
- Commit the design document to git
- Invoke writing-plans skill

## Key Principles

- **One question at a time**
- **Multiple choice preferred**
- **YAGNI ruthlessly**
- **Explore alternatives**
- **Incremental validation**
- **Be flexible**