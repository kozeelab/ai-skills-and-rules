# Using Superpowers

Introduction to the Superpowers skills system.

## The Rule

**Invoke relevant or requested skills BEFORE any response or action.**

Even a 1% chance a skill might apply means you should invoke the skill to check.

## Red Flags

These thoughts mean STOP:

| Thought | Reality |
|---------|---------|
| "This is just a simple question" | Questions are tasks. Check for skills. |
| "I need more context first" | Skill check comes BEFORE clarifying questions. |
| "Let me explore the codebase first" | Skills tell you HOW to explore. Check first. |
| "This doesn't need a formal skill" | If a skill exists, use it. |
| "I'll just do this one thing first" | Check BEFORE doing anything. |

## Skill Priority

When multiple skills could apply:

1. **Process skills first** (brainstorming, debugging)
2. **Implementation skills second**

## Instruction Priority

```
1. User's explicit instructions (highest)
2. Superpowers skills (override defaults)
3. Default system prompt (lowest)
```

## Skill Types

**Rigid** (TDD, debugging): Follow exactly.
**Flexible** (patterns): Adapt principles to context.

## Tool Mapping

Skills use Claude Code tool names. For other platforms:
- See references/copilot-tools.md (Copilot CLI)
- See references/codex-tools.md (Codex)
- See references/gemini-tools.md (Gemini CLI)