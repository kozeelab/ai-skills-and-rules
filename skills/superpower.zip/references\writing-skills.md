# Writing Skills

Create new skills following Superpowers best practices.

## Overview

Skills capture reusable workflows and knowledge. Good skills are:
- Focused on specific situations
- Clear about when to trigger
- Complete with all necessary guidance

## Anatomy of a Skill

```
skill-name/
├── SKILL.md (required)
│   ├── YAML frontmatter (name, description required)
│   └── Markdown instructions
└── Bundled Resources (optional)
    ├── scripts/    - Executable code
    ├── references/ - Docs loaded as needed
    └── assets/     - Templates, icons, fonts
```

## SKILL.md Structure

### Frontmatter
```yaml
---
name: skill-name
description: "When to trigger, what it does. Be specific about contexts."
---
```

### Body Sections
1. **Overview** - What the skill does
2. **When to Use** - Triggers and conditions
3. **The Process** - Step-by-step instructions
4. **Examples** - Input/output patterns
5. **Integration** - How it connects to other skills

## Writing Guidelines

- Use imperative form (do this, not doing this)
- Be specific about triggers
- Include examples
- Explain the why behind recommendations
- Keep under 500 lines if possible

## Testing Skills

1. Write draft skill
2. Create test prompts (2-3 realistic scenarios)
3. Run tests with skill vs baseline
4. Evaluate results
5. Iterate based on feedback

## Progressive Disclosure

Skills use three-level loading:
1. **Metadata** (~100 words) - Always in context
2. **SKILL.md body** (<500 lines) - When skill triggers
3. **Bundled resources** - As needed