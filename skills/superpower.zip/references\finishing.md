# Finishing a Development Branch

Verify tests, present options, execute choice, cleanup.

## The Process

### Step 1: Verify Tests

**Before presenting options, verify tests pass:**
```bash
npm test / cargo test / pytest / go test ./...
```

**If tests fail:**
```
Tests failing (<N> failures). Must fix before completing.
Cannot proceed with merge/PR until tests pass.
```

### Step 2: Determine Base Branch

```bash
git merge-base HEAD main 2>/dev/null || git merge-base HEAD master 2>/dev/null
```

### Step 3: Present Options

```
Implementation complete. What would you like to do?

1. Merge back to <base-branch> locally
2. Push and create a Pull Request
3. Keep the branch as-is
4. Discard this work

Which option?
```

### Step 4: Execute Choice

**Option 1: Merge Locally**
```bash
git checkout <base-branch>
git pull
git merge <feature-branch>
<test command>
git branch -d <feature-branch>
```

**Option 2: Push and Create PR**
```bash
git push -u origin <feature-branch>
gh pr create --title "<title>" --body "..."
```

**Option 3: Keep Branch**
Leave worktree in place for later work.

**Option 4: Discard**
```bash
git checkout <base-branch>
git branch -D <feature-branch>
git worktree remove <worktree-path>
```

### Step 5: Cleanup

- Remove worktree if used
- Verify no leftover files
- Announce completion